<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\AppliedController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\DashboardController;
use App\Course;
use App\Applied;
use App\Employee;
use App\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', function () {
    return view('home');
});

// Signup Form - Show Courses in selection
Route::get('/applied', [AppliedController::class, 'courseSelect']);
// Signup Form save data
Route::post('/success', [AppliedController::class, 'store']);
route::get('/success', function () {
    return view('success');
});

// Adding & Showing Courses
Route::get('/addCourse',[CourseController::class,'index']);
Route::delete('/addCourses/{id}',[CourseController::class,'destroy']);
Route::post('/addCourse', [CourseController::class,'store']);

//DASHBOARD - MAIN
Route::get('/dashboard', function() {
    return view('dashboard.mainboard');
});

Route::get('/dashboard', [DashboardController::class, 'teachersInfo']);

// Dashboard - Applied Students
Route::get('/students', function () {
    return view('students');
});



Route::get('/students', [AppliedController::class, 'index']);
Route::get('/studinfo', [AppliedController::class, 'index']);

Route::get('/studinfo/{id}', [DashboardController::class, 'edit']);

Route::get('/studinfo/{id}', [AppliedController::class, 'edit']);
Route::put('/updateinfo/{id}', [AppliedController::class, 'update']);
Route::delete('/deletestudent/{id}', [AppliedController::class, 'destroy']);

// Dashboard - Employees
Route::get('/add-employees', function () {
    return view('adding.addEmp');
});

Route::post('/add-employees', [EmployeeController::class, 'store']);
Route::get('/employees', [EmployeeController::class, 'index']);

Route::get('/empEdit/{id}', [EmployeeController::class, 'edit']);
Route::put('/updateemp/{id}', [EmployeeController::class, 'update']);
Route::delete('/deleteemp/{id}',[EmployeeController::class,'destroy']);


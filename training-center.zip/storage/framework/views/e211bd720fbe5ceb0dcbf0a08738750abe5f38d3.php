
<?php $__env->startSection('content'); ?>

<div class="flex flex-row">
        <!-- Start Side Bar -->
        <div class="h-screen bg-gray-700 w-1/6 text-white">
            <div class="flex flex-col">
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الرئيسية</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">جميع المتقدمين</div>
                </a>
                <a href="/addCourse">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الدورات</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">دفعات الطلاب</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">رواتب الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">التقارير المالية</div>
                </a>

            </div>
        </div>
        <!-- End Side Bar -->

    <div class="px-8 py-8 flex flex-col w-full" >
    
    <div class="mb-8 py-4 px-4 border border-gray-200 rounded-xl bg-gray-50 flex justify-center">

            <div class=" px-2 my-1 flex justify-center">
                    <h1 class="">ابحث عن طالب</h1>
            </div>
            <div class=" w-1/2 float-right">
                <input type="text" name="search" class="h-8 w-full rounded-lg px-2 focus:outline-none ring-1 ring-yellow-200 focus:ring-2 focus:ring-yellow-400" id="search" placeholder="بحث...">
            </div>
        </div>
        

        <div class="py-2 px-2 text-lg font-bold ">طلبات التسجيل</div>

        <div class="bg-gray-50 border border-gray-200 rounded-xl p-6 mt-2">
            <table class="w-full table-auto border-collapse ">
                <thead class="bg-yellow-300 ">
                    <th class="border border-gray-300 py-2">اسم الموظف</th>
                    <th class="border border-gray-300 py-2">الدفعة</th>
                    <th class="border border-gray-300 py-2">عن شهر</th>
                    <th class="border border-gray-300 py-2">...</th>
                </thead>
                <tbody class="">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td class="border border-gray-300 pr-2"><?php echo e($student->name); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->mobile); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->course->course_title); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->branch); ?></td>
                        <td class="border border-gray-300 pr-2 text-center py-2 ">
                            <a href="/studinfo/<?php echo e($student->id); ?>" type="submit" class="px-2 border border-green-600 text-sm rounded-full hover:bg-green-300 transition-ease-out duration-300" id="confirm-btn">تعديل</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('inclodes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HassaN\Desktop\Projects\laravel\training-center\resources\views/dashboard/salaries.blade.php ENDPATH**/ ?>
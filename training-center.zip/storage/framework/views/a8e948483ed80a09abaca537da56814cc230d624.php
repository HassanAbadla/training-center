
<?php $__env->startSection('content'); ?>

<div class="flex flex-row">
        <!-- Start Side Bar -->
        <div class="h-screen bg-gray-700 w-1/6 text-white">
            <div class="flex flex-col">
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الرئيسية</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">جميع المتقدمين</div>
                </a>
                <a href="/addCourse">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الدورات</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">دفعات الطلاب</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">رواتب الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">التقارير المالية</div>
                </a>

            </div>
        </div>
        <!-- End Side Bar -->

    <div class="px-8 py-8 flex flex-col  w-full" >
        <div class="mb-8 w-2/3 py-4 px-4 border border-gray-200 rounded-xl bg-gray-50 flex justify-center">

            <div class="w-32 px-2 my-1">
                <h1 class="">ابحث عن طالب</h1>
            </div>

            <div class=" w-1/2 float-right">
                <input type="text" name="search" class="h-8 w-full rounded-lg px-2 focus:outline-none ring-1 ring-yellow-200 focus:ring-2 focus:ring-yellow-400">
            </div>
            
            <div class="flex-1 w-32 mr-4 ">
                <button class=" btn border-2 bg-gray-100 border-yellow-500 h-8 w-32 rounded-xl text-yellow-900 hover:bg-yellow-500 hover:text-white transition ease-out duration-500 " type="submit">بحث</button>
            </div>
            
        </div>
        
        <div class=" w-full p-2 border border-gray-200 rounded-xl bg-gray-50">

            <a href="" class="">
                <div class="border rounded-xl p-2 mb-2 flex justify-center  w-full hover:bg-yellow-300 align-middle ">
                    <h1 class=" p-2 flex-1 border-l ">اسم الطالب</h1>
                    <h1 class=" p-2 flex-1 border-l">الدورة</h1>
                    <h1 class=" p-2 flex-1 border-l">الدفعة</h1>
                    <h1 class=" p-2 flex-1 ">التاريخ</h1>
                </div>
            </a>
            <a href="" class="">
                <div class="border rounded-xl p-2 mb-2 flex justify-center  w-full hover:bg-yellow-300 align-middle ">
                    <h1 class=" p-2 flex-1 border-l ">اسم الطالب</h1>
                    <h1 class=" p-2 flex-1 border-l">الدورة</h1>
                    <h1 class=" p-2 flex-1 border-l">الدفعة</h1>
                    <h1 class=" p-2 flex-1 ">التاريخ</h1>
                </div>
            </a>
            <a href="" class="">
                <div class="border rounded-xl p-2 mb-2 flex justify-center  w-full hover:bg-yellow-300 align-middle ">
                    <h1 class=" p-2 flex-1 border-l ">اسم الطالب</h1>
                    <h1 class=" p-2 flex-1 border-l">الدورة</h1>
                    <h1 class=" p-2 flex-1 border-l">الدفعة</h1>
                    <h1 class=" p-2 flex-1 ">التاريخ</h1>
                </div>
            </a>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inclodes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HassaN\Desktop\Projects\laravel\training-center\resources\views/dashboard/payments.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<main class="h-1/2 justify-center bg-gray-800 p-10 flex-col md:grid md:grid-cols-2 gap-8 md:flex-row md:justify-around">
        <div>
            <img src="/img/hero-image.jpg" alt="" class="rounded">
        </div>
        <div class="md:mr-12 mt-4">
            <header class="text-white">
                <h2 class="text-4xl mb-4 text-yellow-400">انضم معنا في أكبر تجمع تعليمي</h2>
                <p class="mb-2">إلتحق في إحدى الدورات التعليمية في اقرب فرع لك</p>
                <p>واستفد من المنح المقدمة من المعهد والجامعات العالمية</p>
                <p class="text-xl mt-4 mb-3 text-yellow-400" >دورات معتمدة من:</p>
                <p>وزارة التربية والتعليم</p>
                <p>جامعة بيرزيت</p>
            </header>

            <div class="flex justify-center mt-6 ">
                <a href="/applied" class=" btn text-yellow-300">
                <div class="btn text-yellow-900 md:text-yellow-400 border-solid border border-yellow-400 bg-yellow-400 md:bg-opacity-0 px-12 py-2 rounded-full hover:bg-yellow-400 hover:text-yellow-900 transition ease-out duration-500">التسجيل</div>
                </a>
            
            </div>
        </div>
    </main>

    <div class="mt-8 mx-12 grid md:grid-cols-3 gap-6 bg-gray-100">
            <div class="bg-gray-50 card bg-white border-2 border-yellow-400 rounded-xl pb-4 flex place-self-center">
                <img src="/img/cert.png" alt="Certifiate" class="flex justify-center h-12 sm:h-32 mt-2 object-auto ">
                <div class="mt-6 mx-4">
                    <span class=" font-bold">منحة محادثة لغة انجليزية</span>
                    <p class="text-s text-gray-700">تعلم مصطلحات ومهارات المحادثة للانخراط في المجتمعات المتحثة باللغة</p>
                </div>
            </div>
            <div class="bg-gray-50 card bg-white border-2 border-yellow-400 rounded-xl pb-4 flex place-self-center">
                <img src="/img/cert.png" alt="Certifiate" class="h-12 sm:h-32 mt-2 object-auto ">
                <div class="mt-6 mx-4">
                    <span class=" font-bold">منحة محادثة لغة انجليزية</span>
                    <p class="text-s text-gray-700">تعلم مصطلحات ومهارات المحادثة للانخراط في المجتمعات المتحثة باللغة</p>
                </div>
            </div>
            <div class="bg-gray-50 card bg-white border-2 border-yellow-400 rounded-xl pb-4 flex place-self-center">
                <img src="/img/cert.png" alt="Certifiate" class="h-12 sm:h-32 mt-2 object-auto ">
                <div class="mt-6 mx-4">
                    <span class=" font-bold">منحة محادثة لغة انجليزية</span>
                    <p class="text-s text-gray-700">تعلم مصطلحات ومهارات المحادثة للانخراط في المجتمعات المتحثة باللغة</p>
                </div>
            </div>
    </div>
    <div class=" p-4 md:px-12 md:py-12 mb-auto">
        
    <div class="bg-gray-50 border p-2 flex-col justify-between md:grid md:grid-cols-2 gap-2 md:p-12 rounded-xl bg-white">
            <div class="m-4">
                <img src="/img/hero-image.jpg" alt="Berziet Training Center" class="rounded w-120 md:pl-4 md:mb-10 ">
            </div>
            <div class="pr-4 h-full flex flex-col">
                <h2 class="text-3xl font-bold mb-4">من نحن!</h2>
                <p>معهد بيرزيت للغات، معهد أسس عام 1999 في مدينة خانيونس، وتم افتتاح.لأول مره في فلسطين ، منحة 90% مقدمة من معهد بيرزيت لدبلوم اللغة الإنجليزية (12 مستوى ) تشمل ( القراءة-الكتابة-الترجمة-التحدث-الإستماع) تشمل طلاب الضفة الغربية وقطاع غزة لأول مره في فلسطين ، منحة 90% مقدمة من معهد بيرزيت لدبلوم اللغة الإنجليزية (12 مستوى ) تشمل ( القراءة-الكتابة-الترجمة-التحدث-الإستماع) تشمل طلاب الضفة الغربية وقطاع غزة .</p>
                <a href="#" class="flex justify-end pb-12 mt-auto place-content-end">
                <div class="btn text-gray-400 border border-gray-400 rounded-full px-6 hover:bg-gray-300 hover:text-gray-800 transition ease-out duration-500 hover:border-yellow-400">
                    اقرأ المزيد
                </div>
                </a>
            </div>
            <div class="m-4">
                <img src="/img/hero-image.jpg" alt="Berziet Training Center" class="rounded w-120 md:pl-4 md:mb-10 ">
            </div>
            <div class="pr-4 h-full flex flex-col">
                <h2 class="text-3xl font-bold mb-4">من نحن!</h2>
                <p>معهد بيرزيت للغات، معهد أسس عام 1999 في مدينة خانيونس، وتم افتتاح.لأول مره في فلسطين ، منحة 90% مقدمة من معهد بيرزيت لدبلوم اللغة الإنجليزية (12 مستوى ) تشمل ( القراءة-الكتابة-الترجمة-التحدث-الإستماع) تشمل طلاب الضفة الغربية وقطاع غزة لأول مره في فلسطين ، منحة 90% مقدمة من معهد بيرزيت لدبلوم اللغة الإنجليزية (12 مستوى ) تشمل ( القراءة-الكتابة-الترجمة-التحدث-الإستماع) تشمل طلاب الضفة الغربية وقطاع غزة .</p>
                <a href="#" class="flex justify-end pb-12 mt-auto place-content-end">
                <div class="btn text-gray-400 border border-gray-400 rounded-full px-6 hover:bg-gray-300 hover:text-gray-800 transition ease-out duration-500 hover:border-yellow-400">
                    اقرأ المزيد
                </div>
                </a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('inclodes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HassaN\Desktop\Projects\laravel\training-center\resources\views/home.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<div class="flex flex-row">
        <!-- Start Side Bar -->
        <div class="h-screen bg-gray-700 w-1/6 text-white">
            <div class="flex flex-col">
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الرئيسية</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">جميع المتقدمين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الدورات</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">دفعات الطلاب</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">رواتب الموظفين</div>
                </a>
                <a href="">
                    <div class="py-4 px-2 text-center hover:bg-yellow-400 transition-ease-out duration-300">التقارير المالية</div>
                </a>

            </div>
        </div>
        <!-- End Side Bar -->

    <div class="px-8 py-8 flex flex-col w-full" >
        <div class="py-2 text-lg font-bold ">طلبات التسجيل</div>

        <div class="bg-white border border-yellow-400 rounded-xl p-6 mt-2">
            <table class="w-full table-auto border-collapse ">
                <thead class="bg-yellow-300 ">
                    <th class="border border-gray-300 py-2">#</th>
                    <th class="border border-gray-300 py-2">اسم الطالب</th>
                    <th class="border border-gray-300 py-2">رقم الجوال</th>
                    <th class="border border-gray-300 py-2">المنحة</th>
                    <th class="border border-gray-300 py-2">الفرع</th>
                    <th class="border border-gray-300 py-2">الحالة</th>
                </thead>
                <tbody class="">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->id); ?></td>
                        <td class="border border-gray-300 pr-2"><?php echo e($student->name); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->mobile); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->courses->course_title); ?></td>
                        <td class="border border-gray-300 pr-2 text-center"><?php echo e($student->branch); ?></td>
                        <td class="border border-gray-300 py-2 px-4 w-1/6">
                            <a href=""><div class="px-4 border border-green-600 text-sm rounded-full hover:bg-green-300 transition-ease-out duration-300 float-right">تأكيد</div>
                        </a>
                        <a href=""><div class="px-4 border border-pink-600 text-sm rounded-full hover:bg-pink-300 transition-ease-out duration-300 float-left">إلغاء</div>
                        </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border border-gray-300 pr-2 text-center">002</td>
                        <td class="border border-gray-300 pr-2">أحمد محمد العبادلة</td>
                        <td class="border border-gray-300 pr-2 text-center">0597768500</td>
                        <td class="border border-gray-300 pr-2 text-center">التوفل</td>
                        <td class="border border-gray-300 pr-2 text-center">خانيونس</td>
                        <td class="border border-gray-300 py-2 px-4 w-1/6">
                            <a href=""><div class="px-4 border border-green-600 text-sm rounded-full hover:bg-green-300 transition-ease-out duration-300 float-right">تأكيد</div>
                            </a>
                            <a href=""><div class="px-4 border border-pink-600 text-sm rounded-full hover:bg-pink-300 transition-ease-out duration-300 float-left">إلغاء</div>
                            </a>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('inclodes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HassaN\Desktop\Projects\laravel\training-center\resources\views/students.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Applied;
use App\Models\Employee;


class DashboardController extends Controller
{

    public function teachersInfo(Request $request)
    {
        $teachers = Employee::all();
        $appCount = Applied::all()->count();
        $empCount = Employee::all()->count();
        $actCount = Applied::all()->where('status','=', 'نشط')->count();
        $inactCount = Applied::all()->where('status','!=', 'نشط')->count();
        $Courses = Course::all();
        $appCourse = Applied::all();
        $inactive = Applied::all()->where('status','!=', 'نشط');

        return view('dashboard.mainboard', [
            'teachers'=> $teachers,
            'appCount' => $appCount,
            'empCount' => $empCount,
            'actCount' => $actCount,
            'inactCount' => $inactCount,
            'Courses' => $Courses,
            'appCourse' => $appCourse,
            'inactives' => $inactive
        ]);
    }

//---------------------//
    public function edit($id)
    {
        $inactives = Applied::find($id);
        // return view('dashboard.studinfo')->with('students', $students);

        return view('dashboard.studinfo', [
            'inactives'=> $inactives = Applied::findOrFail($id)
            // 'courses' => $course = Course::all()
        ]);
    }

}



